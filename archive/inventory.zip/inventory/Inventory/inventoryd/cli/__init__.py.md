"""CLI subsystem for inventoryd."""
