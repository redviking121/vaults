# Razor Governance Map
Tags:: #map #razor

## Purpose
Top-level map of Razor: coherence enforcement, contradiction resolution,
and propagation stability across cognitive and operational layers.

## Core Nodes
- [[Razor Core Principles]]
- [[Razor Enforcement Points]]
- [[Razor–Downshift Integration Layer]]
- [[Razor–Upshift Integration Layer]]

## Structural Nodes
- [[Decision Stability]]
- [[Propagation Coherence]]
- [[Contradiction Resolution]]

## Operator Nodes
- [[Razor Operator’s Manual]]
- [[Razor Field Card]]

## Notes
Every Razor-related Zettel should link here. This map becomes the governance spine.
