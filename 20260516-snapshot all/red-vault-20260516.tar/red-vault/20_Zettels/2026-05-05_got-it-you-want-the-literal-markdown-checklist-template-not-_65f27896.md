---
title: Got it — you want the **literal Markdown checklist template**, not the task card
timestamp: 2026-05-05T00:09:00
uid: 65f27896
source: 202605050009.md
tags: [status:actionable, xi:emphasis, struct:list]
---
Got it — you want the **literal Markdown checklist template**, not the task card. Here is the operator‑grade, vault‑ready template you can drop straight into your Obsidian environment and tick off per plugin.

---

## **Plugin Compliance Checklist (Template)**

```markdown
# Plugin Compliance Checklist
Plugin: {{PLUGIN_NAME}}
Version: {{VERSION}}
Author: {{AUTHOR}}
Date Reviewed: {{DATE}}

---

## 1. Manifest.json
- [ ] `id` is unique, lowercase, no spaces
- [ ] `name` matches plugin folder name
- [ ] `version` follows semver (e.g., 1.0.0)
- [ ] `minAppVersion` is correct for target Obsidian release
- [ ] `description` is present and meaningful
- [ ] `author` and `authorUrl` populated
- [ ] `isDesktopOnly` set correctly
- [ ] No unused or deprecated fields

---

## 2. File & Folder Structure
- [ ] Plugin folder name matches manifest `id`
- [ ] `main.js` or `main.ts` exists
- [ ] `styles.css` present if used
- [ ] `manifest.json` at root
- [ ] No stray build artifacts (`.map`, `node_modules`, etc.)
- [ ] README.md present and accurate

---

## 3. Build Integrity
- [ ] Builds cleanly with no warnings
- [ ] Output contains only required files
- [ ] No TypeScript errors
- [ ] No unused imports or dead code
- [ ] Bundler config (if any) is minimal and correct

---

## 4. Plugin Class Structure
- [ ] Default export extends `Plugin`
- [ ] `onload()` implemented
- [ ] `onunload()` implemented
- [ ] All registered commands cleaned up on unload
- [ ] All event listeners cleaned up on unload
- [ ] Settings (if any) load/save correctly

---

## 5. Commands
- [ ] Commands defined in manifest
- [ ] Commands registered in `onload()`
- [ ] Commands have unique IDs
- [ ] Commands have clear names
- [ ] Commands work as expected

---

## 6. Settings (If Applicable)
- [ ] Settings interface loads without errors
- [ ] Defaults defined in a schema or object
- [ ] Settings persist across reloads
- [ ] Settings UI uses Obsidian components
- [ ] No unused settings fields

---

## 7. UI Elements (If Applicable)
- [ ] Ribbon icons registered/unregistered properly
- [ ] Status bar items cleaned up on unload
- [ ] Modal dialogs open/close cleanly
- [ ] Views registered/unregistered properly

---

## 8. File Operations (If Applicable)
- [ ] Uses Obsidian API (`vault`, `metadataCache`)
- [ ] No direct filesystem calls
- [ ] Handles missing files gracefully
- [ ] No blocking operations on main thread

---

## 9. Performance & Safety
- [ ] No infinite loops or runaway intervals
- [ ] All intervals/timeouts cleared on unload
- [ ] No excessive logging
- [ ] No unsafe DOM manipulation
- [ ] No external network calls unless required

---

## 10. Documentation
- [ ] README includes installation instructions
- [ ] README includes usage examples
- [ ] README includes settings explanation
- [ ] Changelog present and updated
- [ ] License file present

---

## 11. Final Verification
- [ ] Plugin loads without errors
- [ ] Plugin unloads without residue
- [ ] Works in Safe Mode (if applicable)
- [ ] Works on mobile (if applicable)
- [ ] Passes manual smoke test

---

## Notes
{{NOTES}}
```

---

If you want, I can also generate:

- A **short-form version** for rapid triage
- A **strict operator-mode version** with gating logic
- A **plugin‑dev starter folder** containing this template pre‑embedded
- A **CLI‑style checklist** you can run mentally like a preflight

Just tell me which direction you want to take next.