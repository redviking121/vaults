---
title: "MUFON (Mutual UFO Network) has been quite active recently [mufon.com](https://mufon.com/)! Here are some of the latest updates:"
timestamp: "2026-05-13 17:11"
source: 202605041745.md
uid: 8de85d7b
tags: []
---
MUFON (Mutual UFO Network) has been quite active recently [mufon.com](https://mufon.com/)! Here are some of the latest updates:

1. **Mystery Drones**: There have been sightings of drone swarms near U.S. military bases in the UK and the U.S [mufon.com](https://mufon.com/ufo-news/). These drones are sophisticated and have raised concerns about national security [mufon.com](https://mufon.com/ufo-news/).
2. **Oversight Hearing**: MUFON, along with the New Paradigm Institute, announced a UAP Disclosure Event following a House Oversight Hearing [mufon.com](https://mufon.com/ufo-news/). This event aims to promote transparency regarding Unidentified Aerial Phenomena (UAP) [mufon.com](https://mufon.com/ufo-news/).
3. **Symposium**: The 2024 MUFON Symposium is scheduled to take place in the Dallas-Fort Worth area from July 12 to July 14 [mufon.com](https://mufon.com/category/mufon-news/). It's a great opportunity for enthusiasts and researchers to come together and share their findings [mufon.com](https://mufon.com/category/mufon-news/).
4. **Loss of Researchers**: Unfortunately, MUFON has also announced the passing of several prominent UFO researchers, including Dr. Bruce Maccabee and Paul F. Eno [mufon.com](https://mufon.com/category/mufon-news/).

Is there a specific aspect of MUFON's activities you're interested in?