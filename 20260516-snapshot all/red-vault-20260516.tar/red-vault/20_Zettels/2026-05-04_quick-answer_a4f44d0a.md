---
title: **Quick answer:**
timestamp: 2026-05-04T21:15:00
uid: a4f44d0a
source: 202605042115.md
tags: [struct:question, struct:list]
---
**Quick answer:**  
You change the background color in VS Code by either switching to a different **Color Theme** or by editing **workbench.colorCustomizations** in _settings.json_ to set an exact background color. [Visual Studio Code](https://code.visualstudio.com/docs/configure/themes)

---

## 🧩 Two ways to change the background color in VS Code

### 1. **Use a different Color Theme (fastest)**

VS Code themes define the editor background.  
You can switch themes like this:

- **File → Preferences → Theme → Color Theme**  
    _(macOS: Code → Preferences → Theme → Color Theme)_
- Or press:  
    **Ctrl+K Ctrl+T** (Windows/Linux)  
    **⌘K ⌘T** (macOS)

This opens the theme picker where you can preview themes with ↑/↓.  
Themes from the Marketplace can also be installed under **Extensions → @category:"themes"**. [Visual Studio Code](https://code.visualstudio.com/docs/configure/themes)

---

### 2. **Set a custom background color manually (precise control)**

If you want a _specific_ background color (e.g., pure black, soft gray, etc.), you can override the theme using:

#### Steps:

1. Open the Command Palette:  
    **Ctrl+Shift+P** (Windows/Linux) or **⌘Shift+P** (macOS)
2. Type: **Preferences: Open Settings (JSON)**
3. Add or edit this block:

```json
"workbench.colorCustomizations": {
    "editor.background": "#1E1E1E"
}
```

You can customize many UI elements this way (sidebar, activity bar, etc.).  
VS Code provides autocomplete for all available color keys. [microsoft.github.io](https://microsoft.github.io/vscode-essentials/en/03-customization.html)

---

## 🎨 Want to change the whole UI, not just the editor?

You can also set:

```json
"workbench.colorCustomizations": {
    "activityBar.background": "#223355",
    "sideBar.background": "#111111",
    "editor.background": "#000000"
}
```

VS Code’s Theme Color Reference lists every customizable UI color. [microsoft.github.io](https://microsoft.github.io/vscode-essentials/en/03-customization.html)

---

## ⚠️ Note about background images

There are extensions (like _background_) that let you set wallpaper-style images, but they modify the editor DOM and may break after updates. [microsoft.github.io](https://microsoft.github.io/vscode-essentials/en/03-customization.html)

---

## If you tell me the exact color you want (hex, RGB, or “dark blue”), I can generate the exact JSON block for you.