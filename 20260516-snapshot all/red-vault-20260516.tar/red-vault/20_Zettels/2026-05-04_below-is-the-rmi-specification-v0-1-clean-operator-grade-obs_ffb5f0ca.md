---
title: Below is the **RMI Specification v0.1** — clean, operator‑grade, Obsidian‑ready,
timestamp: 2026-05-04T22:35:00
uid: ffb5f0ca
source: 202605042235.md
tags: [status:actionable, struct:list]
---
Below is the **RMI Specification v0.1** — clean, operator‑grade, Obsidian‑ready, zero ceremony, structurally precise. It slots directly into your Ops‑Vault as the canonical contract for Razor modules.

---

# **Razor Module Interface (RMI) — v0.1**

### _Canonical contract for pluggable, testable, offload‑ready Razor modules_

---

## **0. Purpose**

RMI defines the **strict interface** every Razor module must implement to participate in the Razor runtime.  
It guarantees:

- pluggability
- deterministic behavior
- invariant safety
- substrate‑safe state transitions
- agent offload readiness
- independent testability

---

## **1. Module Identity**

Each module declares:

- **ModuleName** — stable identifier
- **Version** — semantic (`major.minor.patch`)
- **Stage** — one of the six Razor stages
- **Capabilities** — verbs describing what the module does
- **Dependencies** — upstream/downstream expectations

Identity is immutable; versioning is the only evolution path.

---

## **2. Input Contract**

Modules accept a **RazorFrame** containing:

- **FrameID** — lineage anchor
- **Payload** — content to transform
- **Context** — operator state, substrate state, environment
- **Constraints** — time, recursion, depth, offload permissions
- **Expectations** — caller‑declared intent

Modules must validate inputs and emit structured errors on violation.

---

## **3. Output Contract**

Modules return a **ModuleResult** containing:

- **ResultPayload** — transformed content
- **Delta** — explicit diff from input
- **Signals** — drift, contradiction, stability, lineage
- **Metrics** — time, memory, recursion depth, offload usage
- **StateUpdate** — substrate write‑back instructions

Outputs must be deterministic under identical inputs and constraints.

---

## **4. Invariants**

Every module must enforce:

- **Lineage Preservation** — no silent mutation
- **Determinism** — no nondeterministic branching
- **No Drift** — intent must not be reinterpreted
- **No Expansion** — no new ontology without protocol
- **No Contraction** — no ontology removal without protocol
- **Stability** — no propagation of unstable decisions

Violation requires halting with a **RazorViolation**.

---

## **5. State Model**

Modules follow a **pure core + effect boundary** model:

- **Core** — deterministic, pure transformation
- **Boundary** — substrate I/O, environment access, agent calls

Core must be fully testable in isolation.

---

## **6. Failure Semantics**

Modules must implement:

- **SoftFailure** — recoverable (missing context, incomplete payload)
- **HardFailure** — unrecoverable (contradiction, invariant break)
- **Timeout** — exceeded constraints
- **OffloadFailure** — agent unavailable or exceeded limits

All failures must emit structured diagnostics.

---

## **7. Offload Interface**

Modules must expose:

- **OffloadEligibility** — boolean + rationale
- **OffloadPlan** — minimal payload for agent
- **OffloadMerge** — deterministic merge of agent output
- **OffloadFallback** — local fallback path

This ensures agent‑ready execution.

---

## **8. Monitoring & Telemetry**

Modules must emit:

- **Lifecycle Events** — start, checkpoint, finish
- **Stability Metrics** — drift, contradiction, compression ratio
- **Performance Metrics** — time, memory, recursion depth
- **Lineage Trace** — explicit change log

Telemetry is mandatory for debugging and substrate repair.

---

## **9. Test Harness Requirements**

Each module must ship with:

- **Golden Tests** — deterministic I/O pairs
- **Invariant Tests** — ensure invariants cannot be violated
- **Stress Tests** — malformed payloads, recursion, depth
- **Offload Tests** — simulated agent round‑trip

This guarantees independent testability.

---

## **10. Upgrade & Versioning Rules**

Modules must follow:

- **Backward Compatibility** — minor versions
- **Breaking Changes** — major versions only
- **Migration Hooks** — optional substrate evolution helpers
- **Deprecation Window** — declared before removal

Ensures safe evolution of the Razor runtime.

---

# **RMI v0.1 — Operator Summary**

RMI defines:

- what a module _is_
- what it _accepts_
- what it _returns_
- what it _must never violate_
- how it _fails_
- how it _offloads_
- how it _is monitored_
- how it _is tested_
- how it _evolves_

This is the contract that turns Razor into a **modular cognitive substrate**.

---

If you want next, I can generate:

- **RMI v0.1 → YAML schema**
- **RMI v0.1 → Obsidian template**
- **RMI v0.1 → compliance checklist**

Pick one and I’ll move forward like a bulldog.