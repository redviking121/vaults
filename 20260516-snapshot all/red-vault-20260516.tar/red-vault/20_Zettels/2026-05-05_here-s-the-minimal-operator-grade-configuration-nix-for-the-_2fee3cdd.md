---
title: Here’s the **minimal, operator‑grade `configuration.nix`** for the Toughbook — t
timestamp: 2026-05-05T00:40:00
uid: 2fee3cdd
source: 202605050040.md
tags: [struct:list]
---
Here’s the **minimal, operator‑grade `configuration.nix`** for the Toughbook — the one that gives you the _real_ NixOS substrate with **no ideology, no flakes, no modules, no critters**, just the cleanest possible airframe to explore.

This is the config I’d hand to an operator who wants to _feel_ NixOS without committing to any architectural decisions yet.

---

# 🧱 Minimal `configuration.nix` for the Toughbook

This assumes:

- Intel graphics (likely true)
- standard Wi‑Fi chipset
- no SecureBoot
- you want SSH
- you want a normal user
- you want a sane editor
- you want nothing else

Everything else is intentionally absent.

```
{ config, pkgs, ... }:

{
  imports = [
    ./hardware-configuration.nix
  ];

  # Hostname
  networking.hostName = "toughbook";

  # Networking
  networking.networkmanager.enable = true;

  # Timezone and locale
  time.timeZone = "America/New_York";
  i18n.defaultLocale = "en_US.UTF-8";

  # Console
  console.keyMap = "us";

  # Bootloader
  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;

  # Users
  users.users.red = {
    isNormalUser = true;
    extraGroups = [ "wheel" "networkmanager" ];
    initialPassword = "changeme";
  };

  # Allow sudo for wheel
  security.sudo.enable = true;
  security.sudo.wheelNeedsPassword = false;

  # Basic packages
  environment.systemPackages = with pkgs; [
    vim
    git
    htop
    wget
    curl
  ];

  # Enable SSH
  services.openssh.enable = true;

  # Enable the firewall (simple defaults)
  networking.firewall.enable = true;

  # Sound (PipeWire)
  sound.enable = true;
  hardware.pulseaudio.enable = false;
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    pulse.enable = true;
  };

  # X11 + basic desktop (optional — uncomment if you want GUI)
  # services.xserver.enable = true;
  # services.xserver.layout = "us";
  # services.xserver.desktopManager.xfce.enable = true;
  # services.xserver.displayManager.lightdm.enable = true;

  system.stateVersion = "24.11";
}
```

---

# 🧭 Why this is the right minimal config

### **1. It gives you the real NixOS substrate**

You get:

- declarative system
- atomic rebuilds
- generations
- rollbacks
- hardware config
- systemd integration

No flakes, no overlays, no Python versions, no critters.

Just the substrate.

### **2. It’s safe**

Nothing here can brick the Toughbook.  
Nothing here is exotic.  
Everything is reversible.

### **3. It’s the perfect exploration airframe**

You can now:

- add services one at a time
- add interpreters one at a time
- add critters one at a time
- test rebuilds
- test rollbacks
- test module layering

Without committing to any architecture.

### **4. It’s intentionally boring**

Because boring is what you want when you’re learning the substrate.

---

# 🧩 Optional: If you want a GUI

Uncomment the X11 block and you get:

- XFCE (lightweight, stable, perfect for Toughbooks)
- LightDM
- sane defaults

But I recommend starting **headless** unless you need the GUI immediately.

---

# 🧭 Next operator step

If you want, I can now sketch:

- the **first rebuild cycle** (what to run, what to expect)
- a **flake migration path** once you’re comfortable
- a **module layout** for your tiny NOC
- a **Python multi‑interpreter substrate**
- or a **service module** for your first critter

Which direction do you want to explore next, Red.