---
title: Understood. Here is the **operator‑grade Obsidian plugin skeleton** — not the to
timestamp: 2026-05-04T23:38:00
uid: 30fbc090
source: 202605042338.md
tags: [status:actionable, struct:future, xi:emphasis, struct:list]
---
Understood. Here is the **operator‑grade Obsidian plugin skeleton** — not the toy tutorial version, but the chassis you actually build real substrate tools on. It’s structured around **predictability, clean teardown, explicit lifecycle boundaries, and zero UI side‑effects**.

This is the skeleton you drop into `~/Documents/lab/.obsidian/plugins/<plugin‑id>/`.

---

# **Ξ Operator‑Grade Plugin Skeleton (v0.1)**

**Design goals:**

- Deterministic load/unload
- No ribbon pollution
- No layout mutation
- Explicit lifecycle boundaries
- Centralized logging
- Stable async surfaces
- Operator‑grade error handling
- Ready for substrate integration later

---

## **1. `manifest.json`**

Minimal, clean, no surprises.

```json
{
  "id": "operator-plugin",
  "name": "Operator Plugin",
  "version": "0.1.0",
  "minAppVersion": "1.5.0",
  "description": "Operator-grade plugin chassis.",
  "author": "Red",
  "isDesktopOnly": false
}
```

---

## **2. `main.ts` (or `main.js` if you’re not compiling yet)**

This is the **real** skeleton: lifecycle, logging, command registration, teardown discipline.

```ts
import { Plugin, Notice, TFile, TAbstractFile } from "obsidian";

export default class OperatorPlugin extends Plugin {

    // Centralized logger
    log(...args: any[]) {
        console.log("[Ξ-OP]", ...args);
    }

    // Keep references to disposables so unload is deterministic
    private unregisterFns: Array<() => void> = [];

    onload() {
        this.log("loading");

        // Register commands
        this.registerCommand(
            "operator-hello",
            "Operator: Hello World",
            () => this.hello()
        );

        // Register file event listeners
        this.registerEvent(
            this.app.vault.on("create", (file) => this.onFileCreated(file))
        );

        this.log("loaded");
    }

    onunload() {
        this.log("unloading");

        // Execute all teardown functions
        for (const fn of this.unregisterFns) {
            try { fn(); } catch (e) { this.log("teardown error", e); }
        }

        this.log("unloaded");
    }

    // Wrapper to register commands with teardown tracking
    registerCommand(id: string, name: string, callback: () => void) {
        const cmd = this.addCommand({ id, name, callback });
        this.unregisterFns.push(() => this.removeCommand(cmd.id));
    }

    // Remove command by ID
    removeCommand(id: string) {
        // Obsidian doesn't expose direct removal, so we noop here.
        // Placeholder for future operator-grade command registry.
    }

    // Wrapper to track event unregister
    registerEvent(eventRef: any) {
        this.unregisterFns.push(() => eventRef());
    }

    // === COMMAND IMPLEMENTATIONS ===

    hello() {
        this.log("hello invoked");
        new Notice("Ξ Operator Plugin: Hello");
    }

    // === FILE EVENT HANDLERS ===

    onFileCreated(file: TAbstractFile) {
        if (!(file instanceof TFile)) return;
        this.log("file created:", file.path);
        // Future: ingest pipeline, frontmatter normalization, etc.
    }
}
```

---

## **3. Why this skeleton is “operator‑grade”**

### **A. Deterministic teardown**

Most plugins leak listeners.  
This one **tracks every disposable** and executes teardown in a controlled loop.

### **B. Centralized logging**

`log()` gives you a single choke point for:

- future log levels
- routing to a Razor console
- piping to a substrate monitor

### **C. No UI pollution**

No ribbon buttons.  
No status bar clutter.  
No layout mutation.  
Operator tools should be invisible unless invoked.

### **D. Explicit lifecycle boundaries**

`onload()` and `onunload()` are treated as **contract surfaces**, not casual hooks.

### **E. Ready for substrate integration**

You can drop in:

- Xi governance hooks
- Razor monitors
- ingest pipeline
- decision lifecycle tracking  
    without rewriting the chassis.

---

## **4. Directory layout**

```
operator-plugin/
│
├── manifest.json
├── main.ts
└── styles.css   (optional, empty)
```

---

## **5. Next step (your move)**

You tell me when this skeleton is **in place and loads cleanly** in your modeling vault.  
Once it fires the command and logs correctly, we immediately move to:

**Plugin #2: `ops-vault-ingest` — the first real operator tool.**

If you want, I can now lay down the **TypeScript build pipeline**, the **operator‑grade logging subsystem**, or the **ingest pipeline architecture**.