---
title: Short version: **Yes — we can absolutely make Obsidian “not see” those two plugi
timestamp: 2026-05-05T00:06:00
uid: a3210436
source: 202605050006.md
tags: [struct:question, status:actionable, struct:list]
---
Short version: **Yes — we can absolutely make Obsidian “not see” those two plugins.**  
And doing so is the cleanest way to rule out plugin‑presence as a cause of Obsidian’s defensive behavior.

There are **three** reliable ways to make Obsidian ignore plugins, and each one isolates a different layer of the substrate. I’ll walk you through them in operator‑grade order of diagnostic value.

---

## 1. **Rename the plugin folders** (fastest, lowest‑impact)

Obsidian only loads plugins from:

```
<Vault>/.obsidian/plugins/<plugin-id>/
```

If the folder name does **not** match a valid plugin ID, Obsidian pretends it doesn’t exist.

### Action:

Rename each plugin folder to something like:

```
<plugin-id>.disabled
```

or

```
zzz_<plugin-id>
```

### Why this works:

- Obsidian’s plugin discovery is literal: folder name must match the manifest’s `id`.
- Renaming the folder removes it from the discovery graph.
- No need to delete anything.

### Diagnostic value:

If Obsidian still behaves strangely after this, the plugins are **not** the trigger.

---

## 2. **Remove the plugin folders entirely** (cleanest substrate test)

This is the “no ambiguity” version.

### Action:

Move the plugin folders out of `.obsidian/plugins/` entirely:

```
mv <Vault>/.obsidian/plugins/<plugin-id> ~/Documents/plugin_quarantine/
```

### Why this works:

- Obsidian has nothing to load.
- No chance of partial reads, corrupted manifests, or ghost metadata.

### Diagnostic value:

If Obsidian still misbehaves, the cause is **not** plugin presence.

---

## 3. **Force Obsidian into a plugin‑blind mode** (vault‑level override)

Obsidian has a vault‑scoped setting that disables all community plugins regardless of what’s on disk.

This is controlled by:

```
<Vault>/.obsidian/app.json
```

Specifically:

```
"communityPlugins": false
```

### Action:

Set `"communityPlugins": false` and restart Obsidian.

### Why this works:

- Obsidian will not even _attempt_ to enumerate the plugin directory.
- This bypasses plugin discovery entirely.
- Even malformed or corrupted plugin folders become irrelevant.

### Diagnostic value:

If Obsidian still shows the same symptoms, the issue is **100% environmental** — not plugin‑related.

---

# Which one should we use for your situation?

Given your goal — **prove that Obsidian is not protecting itself because of those two plugins** — the most decisive sequence is:

1. **Rename the plugin folders** (quick test)
2. If symptoms persist: **move them out of the vault**
3. If symptoms _still_ persist: **set communityPlugins = false**

If Obsidian continues to behave oddly after step 3, then the plugins are not even in the causal chain. The substrate itself is the problem.

---

If you want, tell me the exact paths of the two plugin folders and I’ll give you the precise rename/move commands so we can isolate this cleanly.