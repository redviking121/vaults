---
title: Red — this is the layer where the Academy stops being a vibe and becomes **addre
timestamp: 2026-05-05T01:00:00
uid: f3f76533
source: 202605050100.md
tags: [xi:emphasis, struct:list]
---
Red — this is the layer where the Academy stops being a vibe and becomes **addressable space**.  
Sessions give you the rooms.  
**Naming** gives you the _map_.

Below is the **Operator‑Grade Naming Protocol v1.0** — the signage system for your multi‑session, multi‑agent environment.

No mystique. No poetry. Just architecture.

---

# **NAMING PROTOCOL v1.0 — Operator Grade**

A name is not decoration.  
A name is a **coordinate**.

The purpose of naming in the Academy is:

- instant recognition
- zero ambiguity
- clean sorting
- predictable retrieval
- cognitive smoothness

You want to be able to glance at a list of sessions and know exactly what each room contains.

So we build a naming system that is:

- **structural**
- **minimal**
- **stable**
- **operator‑readable**

---

# **1. The Naming Formula**

Every session name follows the same pattern:

> **[Type] – [Vector] – [Index]**

Where:

- **Type** = the session mode (Exploration, Stabilization, Design, Demonstration, Reflection)
- **Vector** = the object of inquiry (Open‑WebUI, Venv, Academy, Naming, Logs, etc.)
- **Index** = a simple incrementing number (01, 02, 03…)

This gives you names like:

- **Stabilization – Open‑WebUI – 01**
- **Design – Academy Topology – 02**
- **Exploration – Naming Layer – 01**
- **Reflection – Session Protocol – 03**

Readable. Sortable. Zero drift.

---

# **2. The Five Canonical Types (the Academy’s Rooms)**

These are fixed. They never change.

- **Exploration** — mapping unknown terrain
- **Stabilization** — grounding or fixing a system
- **Design** — creating a structure or pattern
- **Demonstration** — producing a visible artifact
- **Reflection** — integrating what was learned

These are your **top‑level namespaces**.

---

# **3. The Vector**

The vector is the _thing being worked on_.

Examples:

- Open‑WebUI
- Venv
- Reverse Proxy
- Academy Topology
- Naming Layer
- Logs
- Plugin Pipeline
- Xanadu Substrate
- Operator Protocols

The vector is always **Title Case**, always **noun‑based**, always **stable**.

---

# **4. The Index**

The index is simply the chronological counter **per vector per type**.

Example:

If you run multiple Stabilization sessions on Open‑WebUI:

- Stabilization – Open‑WebUI – 01
- Stabilization – Open‑WebUI – 02
- Stabilization – Open‑WebUI – 03

This gives you a clean historical trail.

---

# **5. Why this naming works**

Because it gives you:

- **instant scannability**
- **predictable sorting**
- **no semantic drift**
- **no cleverness tax**
- **no cognitive friction**
- **perfect alignment with your Academy metaphor**

It’s the same pattern used in real operator environments, research labs, and intelligence shops.

---

# **6. Optional: The Short Form**

For rapid work, you can use the compressed form:

> **S‑OWUI‑01**  
> **D‑NAMING‑02**  
> **X‑ACADEMY‑01** (Exploration = X)

But the long form is the canonical form.

---

# **7. If you want, we can now build the _Log Routing Protocol_**

Because once you have:

- **Sessions** (rooms)
- **Names** (signage)

…the next layer is **Logs** — the record of what happened in each room.

Say **“Logs”** and we’ll build the operator‑grade log routing system next.