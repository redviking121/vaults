---
title: **RMI v0.1 → YAML schema**
timestamp: 2026-05-04T22:36:00
uid: f9a11a79
source: 202605042236.md
tags: [struct:question, struct:list]
---
**RMI v0.1 → YAML schema**  
Operator‑grade, Obsidian‑ready, zero‑ceremony.  
This is the _schema_, not an instance.  
Every field is typed, scoped, and constrained for Razor‑grade module interchange.

---

## **Razor Module Interface (RMI) — YAML Schema v0.1**

```yaml
# RMI v0.1 — YAML Schema (structural contract)
# Each Razor module MUST conform to this schema.

rmi:
  version: "0.1"        # string — RMI spec version the module targets

  module:
    id:                 # string — globally unique module identifier
    name:               # string — human‑readable module name
    description:        # string — concise operator‑grade summary
    kind:               # enum[string] — {operator, substrate, logic, naming, workflow, parity}

    version:
      major:            # int — breaking changes
      minor:            # int — additive changes
      patch:            # int — fixes only

  io:
    input:
      type:             # enum[string] — {event, state, payload, mixed}
      schema:           # string — reference to canonical message schema version
      constraints:      # list[string] — invariants required before processing
    output:
      type:             # enum[string] — {event, state, payload, mixed}
      schema:           # string — reference to canonical message schema version
      guarantees:       # list[string] — invariants guaranteed after processing

  invariants:
    pre:                # list[string] — must hold before execution
    post:               # list[string] — must hold after execution
    stable_fields:      # list[string] — fields that must not mutate

  state_model:
    mode:               # enum[string] — {stateless, ephemeral, persistent}
    fields:             # list of state fields
      - name:           # string
        type:           # string — primitive or structured
        description:    # string
        persistence:    # enum[string] — {none, memory, disk, external}

  failure:
    modes:              # list[string] — recognized failure categories
    retry:              # enum[string] — {never, safe, idempotent}
    escalation:         # enum[string] — {none, operator, substrate, system}
    telemetry_required: # bool — must emit failure telemetry

  offload:
    supported:          # bool — module can be offloaded to external executor
    contract:
      input_schema:     # string — schema version for offload input
      output_schema:    # string — schema version for offload output
      guarantees:       # list[string] — invariants preserved during offload

  monitoring:
    metrics:            # list of metrics
      - name:           # string
        type:           # enum[string] — {counter, gauge, histogram}
        description:    # string
    trace:
      enabled:          # bool
      fields:           # list[string] — trace fields required

  testing:
    harness:
      required:         # bool — module must ship a test harness
      cases:
        - name:         # string
          description:  # string
          input:        # freeform — example input
          expected:     # freeform — expected output or state transition

  upgrade:
    compatibility:
      backward:         # bool — supports older module versions
      forward:          # bool — tolerates newer module versions
    migration_steps:    # list[string] — required steps when upgrading module
```

---

## **Notes for your Ops‑Vault**

- Schema is **structural**, not prescriptive.
- All enums are **closed sets** unless explicitly extended.
- All lists are **ordered** unless the module declares otherwise.
- This schema is stable under **DSR‑1**: declaration → stabilization → propagation.

---

If you want, I can now generate:

- **RMI v0.1 — JSON Schema**
- **RMI v0.1 — Obsidian Template**
- **RMI v0.1 — Compliance Checklist**
- **RMI v0.1 — Example Module Instance (Operator‑grade)**

Which artifact do you want next?